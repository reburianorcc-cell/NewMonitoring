ILLUSTRATIVE SAMPLE ONLY — not an official cadastral or approved CLUP dataset.
The polygons form a continuous, non-overlapping thematic mosaic in the Daet area for dashboard testing.
Upload SHP, SHX, DBF, PRJ and CPG together. Select MUNICIPAL, BARANGAY and LAND_USE for the respective fields.
