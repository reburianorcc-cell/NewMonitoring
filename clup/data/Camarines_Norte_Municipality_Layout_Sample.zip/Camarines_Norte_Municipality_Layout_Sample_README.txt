Camarines Norte municipality boundary sample derived from the 2023 Philippines PSGC Administrative Boundaries JSON Maps dataset.
Source project: faeldon/philippines-json-maps, which documents its source as altcoder/philippines-psgc-shapefiles and 31 December 2023 PSGC data.
License: MIT for the source repository. Verify against current PSA/NAMRIA data before legal or cadastral use.
